Please note that this game requires Java 7 or higher.
The shortcut to the windows installer for Java 8 is outside of the master folder.
The .jar can run on Windows, Mac, and Linux.

Made by:

HyungJun (Justin) Kim
Calvin Liang
Nicholas Chen