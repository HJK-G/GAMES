package Windows;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.Texture;
import com.fblagamesimulationandprogramming.game.Main;

public class MapScreen extends Window
{
	public MapScreen()
	{
		background = new Texture("fakeimg3.png");

		buttons = null;
	}

	public void update()
	{
		if (Gdx.input.isKeyPressed(Keys.M))// close map
		{
			Main.ingame = true;
			Main.currentScreen = null;
		}
	}

	public void handleButton(Button currentButton)
	{
	}
	// else if (Gdx.input.isKeyPressed(Keys.M))// open map
	// {
	// Main.ingame = false;
	// Main.currentScreen = new MapScreen();
	// }

}
